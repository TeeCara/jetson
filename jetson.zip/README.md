# 🌡️ 온습도 센서 챗봇

Jetson Nano와 Arduino 기반으로 DHT11 센서 데이터를 받아 사용자의 질문에 실시간 응답하는 Gradio 챗봇입니다.

## 🛠️ 사용 기술

- Python 3.8+
- Gradio
- PySerial
- Arduino + DHT11
- Jetson Nano

## 📁 프로젝트 구조

| 파일명            | 설명                        |
|------------------|-----------------------------|
| `chatbot.py`     | 센서 데이터 읽고 챗봇 응답 |
| `arduino_dht.ino`| DHT11 센서 값 전송용 코드  |
| `requirements.txt`| 파이썬 패키지 목록         |
| `images/`         | 실행화면 캡처 저장 폴더   |

## 🚀 실행 방법

1. Arduino에 DHT11 센서를 연결하고 `arduino_dht.ino` 업로드
2. Jetson Nano에서 시리얼 포트 확인
3. 아래 명령어 실행:

```bash
pip install -r requirements.txt
python chatbot.py
```

## 🖥️ Gradio 챗봇 UI

<img src="images/demo_ui.png" width="400">

## 🔧 오류 해결

```bash
sudo chmod 666 /dev/ttyACM0
sudo usermod -a -G dialout 사용자명
```

## 📈 향후 개선

- DHT22 등 센서 확장
- 챗봇 응답 다양화 및 자연어 처리
- 웹 배포 (Gradio Share)

## 📄 라이선스

MIT License

## 👨‍💻 제작자

- 이예준
