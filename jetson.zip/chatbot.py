import serial
import time
import threading
import gradio as gr

class SensorBot:
    def __init__(self, port="/dev/ttyACM0", baudrate=115200):
        self.serial_port = serial.Serial(port, baudrate, timeout=1)
        self.current_temp = None
        self.current_humidity = None
        self.running = True
        threading.Thread(target=self.read_sensor_data, daemon=True).start()

    def read_sensor_data(self):
        while self.running:
            try:
                line = self.serial_port.readline()
                text = line.decode('utf-8').strip()
                temp_str, humid_str = text.split(',')
                self.current_temp = int(temp_str)
                self.current_humidity = int(humid_str)
            except:
                continue

    def process_message(self, msg):
        msg = msg.lower()
        if "온도" in msg:
            return f"우리 집의 현재 온도는 {self.current_temp}°C예요~" if self.current_temp is not None else "온도를 아직 읽지 못했어요."
        elif "습도" in msg:
            return f"현재 습도는 {self.current_humidity}%입니다~" if self.current_humidity is not None else "습도를 아직 읽지 못했어요."
        else:
            return "온도나 습도에 대해 물어보세요~"

bot = SensorBot()

demo = gr.Interface(
    fn=bot.process_message,
    inputs=gr.Textbox(placeholder="질문을 입력하세요 (예: 지금 온도는 어때요?)"),
    outputs="text",
    title="온습도 센서 챗봇",
    description="젯슨맘의 온습도 챗봇입니다. 온도나 습도에 대해 물어보세요!"
)

demo.launch()
